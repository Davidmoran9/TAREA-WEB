﻿window.onload = function () {
    listarLaboratorios();
};

let objLaboratorios;

async function listarLaboratorios() {
    objLaboratorios = {
        url: "Laboratorio/listarLaboratorios",
        cabeceras: ["ID Laboratorio", "Nombre", "Dirección", "Persona Contacto"],
        propiedades: ["idLaboratorio", "nombre", "direccion", "personaContacto"],
        editar: true,
        eliminar: true,
        propiedadId: "idLaboratorio"
    };
    pintar(objLaboratorios);
}
function LimpiarLaboratorio() {
    LimpiarDatos("frmGuardarLaboratorio");
}
function GuardarLaboratorio() {
    let forma = document.getElementById("frmGuardarLaboratorio");
    let frm = new FormData(forma);

    fetchPost("Laboratorio/GuardarLaboratorio", "text", frm, function (res) {
        Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Laboratorio agregado correctamente'
        });
        toastr.success("Laboratorio agregado correctamente.");
        listarLaboratorios();
        LimpiarLaboratorio();
        cerrarModal();
    });
}
function Editar(id) {
    fetchGet("Laboratorio/recuperarLaboratorio/?idLaboratorio=" + id, "json", function (data) {
        setN("idLaboratorio", data.idLaboratorio);
        setN("nombre", data.nombre);
        setN("direccion", data.direccion);
        setN("personaContacto", data.personaContacto);
        setN("numeroContacto", data.numeroContacto);
        abrirModal();
    });
}

function GuardarCambiosLaboratorio() {
    let forma = document.getElementById("frmGuardarLaboratorio");
    let frm = new FormData(forma);

    fetchPost("Laboratorio/GuardarCambiosLaboratorio", "text", frm, function (res) {
        Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Laboratorio modificado correctamente'
        });
        toastr.success("Laboratorio modificado correctamente.");
        listarLaboratorios();
        LimpiarLaboratorio();
        cerrarModal();
    });
}
function Eliminar(id) {
    Swal.fire({
        title: "¿Estás seguro?",
        text: "Esta acción no se puede deshacer",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Sí, eliminar"
    }).then((result) => {
        if (result.isConfirmed) {
            fetchGet("Laboratorio/eliminarLaboratorio/?idLaboratorio=" + id, "json", function (res) {
                if (res.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Eliminado',
                        text: 'Laboratorio eliminado correctamente'
                    });
                    toastr.success("Laboratorio eliminado correctamente.");
                    listarLaboratorios();
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'No se pudo eliminar. Puede que el registro no exista.'
                    });
                    toastr.error("No se pudo eliminar el laboratorio.");
                }
            });
        }
    });
}
function BuscarLaboratorio() {
    let filtro = document.getElementById("buscarLaboratorio").value.toLowerCase();
    let filas = document.querySelectorAll("#divTable tbody tr");

    filas.forEach(fila => {
        let textoFila = fila.innerText.toLowerCase();
        fila.style.display = textoFila.includes(filtro) ? "" : "none";
    });
}
function abrirModal() {
    let modal = new bootstrap.Modal(document.getElementById("modalLaboratorio"));
    modal.show();
}
function cerrarModal() {
    let modalEl = document.getElementById("modalLaboratorio");
    let modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) {
        modal.hide();
    }
}
