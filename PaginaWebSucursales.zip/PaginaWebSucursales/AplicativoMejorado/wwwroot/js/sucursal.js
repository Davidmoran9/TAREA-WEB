﻿window.onload = function () {
    listarSucursales();
};

let objSucursales;

async function listarSucursales() {
    objSucursales = {
        url: "Sucursal/listarSucursales",
        cabeceras: ["ID Sucursal", "Nombre", "Dirección"],
        propiedades: ["idSucursal", "nombre", "direccion"],
        editar: true,
        eliminar: true,
        propiedadId: "idSucursal"
    };
    pintar(objSucursales);
}
function LimpiarSucursal() {
    LimpiarDatos("frmGuardarSucursal");
}
function GuardarSucursal() {
    let forma = document.getElementById("frmGuardarSucursal");
    let frm = new FormData(forma);

    fetchPost("Sucursal/GuardarSucursal", "text", frm, function (res) {
        Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Sucursal agregada correctamente'
        });
        toastr.success("Sucursal agregada correctamente.");
        listarSucursales();
        LimpiarSucursal();
        cerrarModal();
    });
}
function Editar(id) {
    fetchGet("Sucursal/recuperarSucursal/?idSucursal=" + id, "json", function (data) {
        setN("idSucursal", data.idSucursal);
        setN("nombre", data.nombre);
        setN("direccion", data.direccion);
        abrirModal();
    });
}
function GuardarCambiosSucursal() {
    let forma = document.getElementById("frmGuardarSucursal");
    let frm = new FormData(forma);

    fetchPost("Sucursal/GuardarCambiosSucursal", "text", frm, function (res) {
        Swal.fire({
            icon: 'success',
            title: 'Éxito',
            text: 'Sucursal modificada correctamente'
        });
        toastr.success("Sucursal modificada correctamente.");
        listarSucursales();
        LimpiarSucursal();
        cerrarModal();
    });
}
function BuscarSucursal() {
    let filtro = document.getElementById("txtBuscar").value.toLowerCase();
    let filas = document.querySelectorAll("#divTable table tbody tr");

    filas.forEach(fila => {
        let texto = fila.textContent.toLowerCase();
        fila.style.display = texto.includes(filtro) ? "" : "none";
    });
}

function Eliminar(id) {
    Swal.fire({
        title: "¿Estás seguro?",
        text: "Esta acción no se puede deshacer",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Sí, eliminar"
    }).then((result) => {
        if (result.isConfirmed) {
            fetchGet("Sucursal/eliminarSucursal/?idSucursal=" + id, "json", function (res) {
                if (res.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Eliminado',
                        text: 'Sucursal eliminada correctamente'
                    });
                    toastr.success("Sucursal eliminada correctamente.");
                    listarSucursales();
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'No se pudo eliminar. Puede que el registro no exista.'
                    });
                    toastr.error("No se pudo eliminar la sucursal.");
                }
            });
        }
    });
}
function abrirModal() {
    let modal = new bootstrap.Modal(document.getElementById("modalSucursal"));
    modal.show();
}
function cerrarModal() {
    let modalEl = document.getElementById("modalSucursal");
    let modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) {
        modal.hide();
    }
}
