﻿window.onload = function () {
    listarTiposMedicamento();
    verificarToastr();
};
function verificarToastr() {
    setTimeout(() => {
        if (typeof toastr !== "undefined") {
            toastr.success("Cargado correctamente.");
        } else {
            console.error("Toastr no está definido. Verifica la inclusión del script.");
        }
    }, 1000);
}
function filtrarTiposMedicamento() {
    let nombre = get("txtTipoMedicamento");
    if (nombre === "") {
        listarTiposMedicamento();
    } else {
        objTiposMedicamento.url = "TipoMedicamento/filtrarTiposMedicamento/?nombre=" + nombre;
        pintar(objTiposMedicamento);
    }
}

let objTiposMedicamento;

async function listarTiposMedicamento() {
    objTiposMedicamento = {
        url: "TipoMedicamento/listarTiposMedicamento",
        cabeceras: ["ID Tipo Medicamento", "Nombre", "Descripción"],
        propiedades: ["idTipoMedicamento", "nombre", "descripcion"],
        editar: true,
        eliminar: true,
        propiedadId: "idTipoMedicamento"
    };
    pintar(objTiposMedicamento);
}

function LimpiarTipoMedicamento() {
    LimpiarDatos("frmGuardarTipoMedicamento");
}
function GuardarTipoMedicamento() {
    let forma = document.getElementById("frmGuardarTipoMedicamento");
    let frm = new FormData(forma);

    fetchPost("TipoMedicamento/GuardarTipoMedicamento", "text", frm, function () {
        mostrarMensaje("success", "Tipo de medicamento agregado correctamente");
        listarTiposMedicamento();
        LimpiarTipoMedicamento();
        $('#modalTipoMedicamento').modal('hide');
    });
}
function Editar(id) {
    fetchGet("TipoMedicamento/recuperarTipoMedicamento/?idTipoMedicamento=" + id, "json", function (data) {
        setN("idTipoMedicamento", data.idTipoMedicamento);
        setN("nombre", data.nombre);
        setN("descripcion", data.descripcion);
        $('#modalTipoMedicamento').modal('show');
    });
}
function GuardarCambiosTipoMedicamento() {
    let forma = document.getElementById("frmGuardarTipoMedicamento");
    let frm = new FormData(forma);

    fetchPost("TipoMedicamento/GuardarCambiosTipoMedicamento", "text", frm, function () {
        mostrarMensaje("success", "Tipo de medicamento modificado correctamente");
        listarTiposMedicamento();
        LimpiarTipoMedicamento();
        $('#modalTipoMedicamento').modal('hide');
    });
}
function Eliminar(id) {
    Swal.fire({
        title: "Estas seguro?",
        text: "Esta acción no se puede deshacer",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Sí, eliminar"
    }).then((result) => {
        if (result.isConfirmed) {
            fetchGet("TipoMedicamento/eliminarTipoMedicamento/?idTipoMedicamento=" + id, "json", function (res) {
                if (res.success) {
                    mostrarMensaje("success", "Tipo de medicamento eliminado correctamente");
                    listarTiposMedicamento();
                } else {
                    mostrarMensaje("error", "No se pudo eliminar el tipo de medicamento. Puede que el registro no exista.");
                }
            });
        }
    });
}

function mostrarMensaje(tipo, mensaje) {
    Swal.fire({
        icon: tipo,
        title: tipo.charAt(0).toUpperCase() + tipo.slice(1),
        text: mensaje
    });

    if (typeof toastr !== "undefined") {
        toastr[tipo](mensaje);
    } else {
        console.error("Toastr no está definido. Verifica la inclusión del script.");
    }
}
