﻿window.onload = function () {
    listarMedicamentos();
    cargarTiposMedicamentos();
    cargarLaboratorios();
};

let objMedicamento;

async function listarMedicamentos() {
    objMedicamento = {
        url: "Medicamento/listarMedicamentos",
        cabeceras: ["id Medicamento", "codigo", "nombre Medicamento", "laboratorio", "Tipo Medicamento", "Uso Medicamento", "Contenido"],
        propiedades: ["idMedicamento", "codigo", "nombreMedicamento", "nombreLaboratorio", "tipoMedicamento", "usoMedicamento", "contenido"],
        editar: true,
        eliminar: true,
        propiedadId: "idMedicamento"
    }
    pintar(objMedicamento);
}

function LimpiarMedicamento() {
    LimpiarDatos("frmBusqueda");
    listarMedicamentos();
}

function cargarTiposMedicamentos() {
    fetch("/Medicamento/ObtenerTiposMedicamentos")
        .then(response => response.json())
        .then(data => {
            let selects = [
                document.getElementById("selectTipoMedicamento"),
                document.getElementById("editselectTipoMedicamento")
            ];
            selects.forEach(select => {
                if (select) {
                    select.innerHTML = ""; 
                    data.forEach(item => {
                        let option = document.createElement("option");
                        option.value = item.idTipoMedicamento;
                        option.text = item.nombre;
                        select.add(option);
                    });
                }
            });
        })
        .catch(error => console.error('Error:', error));
}

function cargarLaboratorios() {
    fetch("/Medicamento/ObtenerLaboratorios")
        .then(response => response.json())
        .then(data => {
            let selects = [
                document.getElementById("selectLaboratorio"),
                document.getElementById("editselectLaboratorio")
            ];
            selects.forEach(select => {
                if (select) {
                    select.innerHTML = ""; 
                    data.forEach(item => {
                        let option = document.createElement("option");
                        option.value = item.idLaboratorio;
                        option.text = item.nombre;
                        select.add(option);
                    });
                }
            });
        })
        .catch(error => console.error('Error:', error));
}

function GuardarMedicamento() {
    let forma = document.getElementById("frmCrearMedicamento");
    let frm = new FormData(forma);

    fetchPost("Medicamento/GuardarMedicamento", "text", frm, function (res) {
        listarMedicamentos();
        LimpiarDatos("frmCrearMedicamento");
        let modalElement = document.getElementById("modalMedicamento");
        let modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) {
            modal.hide();
        }
        document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());
        let toast = new bootstrap.Toast(document.getElementById("toastSuccess"));
        toast.show();
    });
}

function Editar(id) {
    let modal = new bootstrap.Modal(document.getElementById("modalMedicamento"));
    modal.show();
    fetchGet(`Medicamento/recuperarMedicamento/?idMedicamento=${id}`, "json", function (data) {
        if (data) {
            set("idMedicamento", data.idMedicamento);
            set("codigo", data.codigo);
            set("nombreMedicamento", data.nombreMedicamento);
            set("selectTipoMedicamento", data.idTipoMedicamento);
            set("selectLaboratorio", data.idLaboratorio);
            set("usoMedicamento", data.usoMedicamento);
            set("contenido", data.contenido);
        }
    });
}

function GuardarCambioMedicamento() {
    let forma = document.getElementById("frmCrearMedicamento");
    let frm = new FormData(forma);

    for (let pair of frm.entries()) {
        console.log(pair[0] + ": " + pair[1]);
    }

    fetchPost("Medicamento/GuardarCambioMedicamento", "text", frm, function (rspt) {
        listarMedicamentos();
        LimpiarDatos("frmCrearMedicamento");

        Swal.fire({
            title: "Actualizado!",
            text: `El medicamento ha sido actualizado.`,
            icon: "success"
        });

        let modalElement = document.getElementById("modalMedicamento");
        let modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
        modal.hide();

        document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

        let toast = new bootstrap.Toast(document.getElementById("toastSuccessEdit"));
        toast.show();
    });
}
function BuscarMedicamento() {
    let filtro = document.getElementById("buscarMedicamento").value.toLowerCase();
    let filas = document.querySelectorAll("#divTable tbody tr");

    filas.forEach(fila => {
        let textoFila = fila.innerText.toLowerCase();
        if (textoFila.includes(filtro)) {
            fila.style.display = "";
        } else {
            fila.style.display = "none";
        }
    });
}
function BuscarMedicamento() {
    let filtro = document.getElementById("txtBuscar").value.toLowerCase();
    let filas = document.querySelectorAll("#divTable table tbody tr");

    filas.forEach(fila => {
        let texto = fila.textContent.toLowerCase();
        fila.style.display = texto.includes(filtro) ? "" : "none";
    });
}

function Eliminar(id) {
    Swal.fire({
        title: "¿Estás seguro?",
        text: "Esta acción no se puede deshacer",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Sí, eliminar"
    }).then((result) => {
        if (result.isConfirmed) {
            fetchGet(`Medicamento/eliminarMedicamento/?idMedicamento=${id}`, "text", function (res) {
                listarMedicamentos();
                Swal.fire({
                    title: "Eliminado!",
                    text: "El medicamento ha sido eliminado.",
                    icon: "success"
                });
            });
        }
    });
}
